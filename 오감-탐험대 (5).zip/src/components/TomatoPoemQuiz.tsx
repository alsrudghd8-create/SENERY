import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Check, ArrowRight, RotateCcw, Heart, Sparkles, HelpCircle } from 'lucide-react';
import { playClick, playSuccess, playIncorrect, playFanfare } from '../audio';
import { SensoryWord } from '../types';
import confetti from 'canvas-confetti';

interface TomatoPoemQuizProps {
  poemSuccess: boolean;
  clickedPoemWords: string[];
  TOMATO_POEM_WORDS: SensoryWord[];
  onReset: () => void;
}

export default function TomatoPoemQuiz({
  poemSuccess,
  clickedPoemWords,
  TOMATO_POEM_WORDS,
  onReset
}: TomatoPoemQuizProps) {
  // Quiz states
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1); // 1: Question 1, 2: Question 2, 3: Completed summary
  const [selectedAnswer1, setSelectedAnswer1] = useState<number | null>(null);
  const [selectedAnswer2, setSelectedAnswer2] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);

  const q1Options = [
    { id: 1, text: "🍱 급식시간에 먹는 맛있는 방울토마토 반찬", isCorrect: false },
    { id: 2, text: "👶 일곱 살 난 귀엽고 사랑스러운 내 동생", isCorrect: true },
    { id: 3, text: "🐱 학교 앞 골목길에서 노는 아기 길고양이", isCorrect: false }
  ];

  const q2Options = [
    { id: 1, text: "💖 동생의 상큼하고 풋풋한 귀여움이 오감으로 생생하게 느껴지며 매력이 극대화된다!", isCorrect: true },
    { id: 2, text: "🧟 동생이 진짜 빨간 방울토마토 괴물로 변신할 수 있게 마법을 부린다.", isCorrect: false },
    { id: 3, text: "📝 시의 글자 수만 길게 늘려서 복잡하게 만들고, 아무런 감동을 주지 못한다.", isCorrect: false }
  ];

  const handleQ1Select = (optionId: number, isRight: boolean) => {
    setSelectedAnswer1(optionId);
    setShowFeedback(true);
    setIsCorrect(isRight);

    if (isRight) {
      playSuccess();
      confetti({
        particleCount: 40,
        spread: 45,
        origin: { y: 0.6 },
        colors: ['#2ED573', '#FFD32D', '#1E90FF']
      });
    } else {
      playIncorrect();
    }
  };

  const handleQ2Select = (optionId: number, isRight: boolean) => {
    setSelectedAnswer2(optionId);
    setShowFeedback(true);
    setIsCorrect(isRight);

    if (isRight) {
      playFanfare();
      confetti({
        particleCount: 150,
        spread: 90,
        origin: { y: 0.65 },
        colors: ['#FF4757', '#FFD32D', '#2ED573', '#1E90FF', '#A020F0']
      });
      // Move to final step after short delay so they can read success
      setTimeout(() => {
        setCurrentStep(3);
        setShowFeedback(false);
      }, 1800);
    } else {
      playIncorrect();
    }
  };

  const handleNextStep = () => {
    playClick();
    setCurrentStep(2);
    setSelectedAnswer2(null);
    setShowFeedback(false);
    setIsCorrect(false);
  };

  const handleResetQuiz = () => {
    setCurrentStep(1);
    setSelectedAnswer1(null);
    setSelectedAnswer2(null);
    setShowFeedback(false);
    setIsCorrect(false);
    onReset();
  };

  return (
    <div className="bg-[#1A1A1A] text-white p-6 rounded-2xl border-4 border-black shadow-[10px_10px_0px_rgba(0,0,0,1)] flex-1 flex flex-col justify-between gap-4 min-h-[420px]">
      
      {/* Quiz / Status Header */}
      <div className="flex items-center justify-between border-b-2 border-dashed border-neutral-700 pb-3">
        <div className="flex items-center gap-2.5 text-[#FFD32D] font-black text-sm md:text-xl">
          <Trophy className="w-6 h-6 text-[#FFD32D] animate-bounce" />
          <span>
            {!poemSuccess 
              ? `[1단계] 감각 단서 탐색 (${clickedPoemWords.length}/3)` 
              : currentStep === 1 
                ? `[2단계] 수사 퀴즈 1 (동생 찾기)` 
                : currentStep === 2 
                  ? `[3단계] 수사 퀴즈 2 (귀여움의 비밀)` 
                  : `[완료] 감각의 기적 밝혀냄! 🏆`
            }
          </span>
        </div>
        
        {poemSuccess && currentStep < 3 && (
          <span className="bg-[#FF4757] text-white border-2 border-black font-mono text-xs md:text-sm font-black px-3 py-1 rounded-md shadow-[2px_2px_0px_rgba(0,0,0,1)]">
            STAGE {currentStep}/2
          </span>
        )}
      </div>

      {/* Main Body */}
      <div className="flex-1 flex flex-col justify-center py-3">
        <AnimatePresence mode="wait">
          {!poemSuccess ? (
            /* PHASE 1: Find Sensory Words progress list */
            <motion.div
              key="phase1"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              <div className="bg-[#2D2D2D] p-4 rounded-xl border-2 border-neutral-700 text-sm md:text-base text-neutral-200 font-bold leading-relaxed mb-4">
                💡 <strong>수사 가이드:</strong> 왼쪽 시의 노란 점선으로 둘러싸인 <strong>감각적 표현(단서) 3개</strong>를 찾아 마우스로 탭해보세요! 모든 단서를 수집하면 귀여운 동생의 비밀 퀴즈가 풀립니다!
              </div>

              <div className="space-y-3">
                {TOMATO_POEM_WORDS.map((w, idx) => {
                  const isFound = clickedPoemWords.includes(w.text);
                  return (
                    <div 
                      key={idx}
                      className={`p-4 rounded-xl border-2.5 flex items-center justify-between text-sm md:text-lg font-black transition-all ${
                        isFound 
                          ? 'bg-[#2D2D2D]/60 border-black text-[#2ED573] shadow-[3px_3px_0px_rgba(0,0,0,1)]' 
                          : 'bg-neutral-800/40 border-dashed border-neutral-600 text-neutral-500'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs ${
                          isFound ? 'bg-[#2ED573] text-black' : 'bg-neutral-700 text-neutral-400'
                        }`}>
                          {idx + 1}
                        </span>
                        <span>{isFound ? `"${w.text}" : [${w.sense}] 수집 완료!` : `감각 단서 ${idx + 1} 수색 진행 중...`}</span>
                      </div>
                      {isFound && <Check className="w-5 h-5 text-[#2ED573] stroke-[3px]" />}
                    </div>
                  );
                })}
              </div>
            </motion.div>
          ) : currentStep === 1 ? (
            /* PHASE 2: Quiz Question 1 */
            <motion.div
              key="quiz1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="text-base md:text-xl font-black text-neutral-100 flex items-start gap-2.5 leading-relaxed">
                <HelpCircle className="w-6 h-6 text-[#FFD32D] shrink-0 mt-0.5" />
                <span>시 속에서 방울토마토를 통해 궁극적으로 표현하고 싶었던 진짜 주인공(대상)은 누구일까요?</span>
              </div>

              <div className="space-y-3 pt-2">
                {q1Options.map((opt) => {
                  const isSelected = selectedAnswer1 === opt.id;
                  let btnStyle = "bg-neutral-800 hover:bg-neutral-700 border-neutral-600 text-neutral-200";
                  if (selectedAnswer1 !== null) {
                    if (opt.isCorrect) {
                      btnStyle = "bg-emerald-950/70 border-[#2ED573] text-[#2ED573] shadow-[4px_4px_0px_rgba(46,213,115,0.4)]";
                    } else if (isSelected) {
                      btnStyle = "bg-rose-950/70 border-[#FF4757] text-[#FF4757] shadow-[4px_4px_0px_rgba(255,71,87,0.4)]";
                    } else {
                      btnStyle = "bg-neutral-900 border-neutral-800 text-neutral-600 opacity-60";
                    }
                  }

                  return (
                    <button
                      key={opt.id}
                      disabled={selectedAnswer1 !== null}
                      onClick={() => handleQ1Select(opt.id, opt.isCorrect)}
                      className={`w-full text-left p-4.5 rounded-2xl border-3 text-sm md:text-lg font-black transition-all cursor-pointer ${btnStyle}`}
                    >
                      {opt.text}
                    </button>
                  );
                })}
              </div>

              {/* Feedback Q1 */}
              {showFeedback && selectedAnswer1 !== null && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`p-4 rounded-xl border-2 text-sm md:text-base font-extrabold leading-relaxed mt-2.5 ${
                    isCorrect 
                      ? 'bg-emerald-950/50 border-emerald-500 text-emerald-200' 
                      : 'bg-rose-950/50 border-rose-500 text-rose-200'
                  }`}
                >
                  {isCorrect ? (
                    <div className="flex items-center gap-2">
                      <span>🎉 <strong>정답입니다!</strong> 맞아요! 시의 제일 마지막 구절 "방울 토마토는 일곱 살 내 동생"에 나온 것처럼, 시인은 방울 토마토를 통해 사랑스러운 동생을 표현하고 싶었답니다! 👦👧</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span>❌ <strong>다시 생각해 볼까요?</strong> 시의 마지막 줄 "방울 토마토는 일곱 살 내 동생"을 힌트 삼아 다시 추리해 보세요! 어서 동생을 구하러(?) 가봅시다!</span>
                    </div>
                  )}
                </motion.div>
              )}

              {selectedAnswer1 !== null && isCorrect && (
                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleNextStep}
                    className="flex items-center gap-2 px-6 py-3.5 bg-[#2ED573] hover:bg-[#26af5f] text-black font-black text-sm md:text-lg border-2 border-black rounded-xl shadow-[4px_4px_0px_rgba(0,0,0,1)] hover:scale-105 transition-all cursor-pointer"
                  >
                    <span>다음 질문으로 넘어가기</span>
                    <ArrowRight className="w-4 h-4 stroke-[3px]" />
                  </button>
                </div>
              )}
            </motion.div>
          ) : currentStep === 2 ? (
            /* PHASE 3: Quiz Question 2 */
            <motion.div
              key="quiz2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="text-base md:text-xl font-black text-neutral-100 flex items-start gap-2.5 leading-relaxed">
                <HelpCircle className="w-6 h-6 text-[#FFD32D] shrink-0 mt-0.5" />
                <span>그렇다면 '빨갛게 익은', '새콤달콤한', '탱글탱글한' 과 같은 풍부한 감각적 표현은 '내 동생'에게 어떤 기적을 불러일으킬까요?</span>
              </div>

              <div className="space-y-3 pt-2">
                {q2Options.map((opt) => {
                  const isSelected = selectedAnswer2 === opt.id;
                  let btnStyle = "bg-neutral-800 hover:bg-neutral-700 border-neutral-600 text-neutral-200";
                  if (selectedAnswer2 !== null) {
                    if (opt.isCorrect) {
                      btnStyle = "bg-emerald-950/70 border-[#2ED573] text-[#2ED573] shadow-[4px_4px_0px_rgba(46,213,115,0.4)]";
                    } else if (isSelected) {
                      btnStyle = "bg-rose-950/70 border-[#FF4757] text-[#FF4757] shadow-[4px_4px_0px_rgba(255,71,87,0.4)]";
                    } else {
                      btnStyle = "bg-neutral-900 border-neutral-800 text-neutral-600 opacity-60";
                    }
                  }

                  return (
                    <button
                      key={opt.id}
                      disabled={selectedAnswer2 !== null}
                      onClick={() => handleQ2Select(opt.id, opt.isCorrect)}
                      className={`w-full text-left p-4.5 rounded-2xl border-3 text-sm md:text-lg font-black transition-all cursor-pointer ${btnStyle}`}
                    >
                      {opt.text}
                    </button>
                  );
                })}
              </div>

              {/* Feedback Q2 */}
              {showFeedback && selectedAnswer2 !== null && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`p-4 rounded-xl border-2 text-sm md:text-base font-extrabold leading-relaxed mt-2.5 ${
                    isCorrect 
                      ? 'bg-emerald-950/50 border-emerald-500 text-emerald-200' 
                      : 'bg-rose-950/50 border-rose-500 text-rose-200'
                  }`}
                >
                  {isCorrect ? (
                    <div className="flex items-center gap-2">
                      <span>🏆 <strong>경축! 오감 수사 완료!</strong> 동생의 생기 넘치는 귀여움이 한껏 전해집니다! 최종 요약 노트를 확인해 볼까요?</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span>❌ <strong>아쉬워요!</strong> 감각 표현이 빠진 "동생은 일곱 살이고 얼굴이 붉다"는 밋밋하지만, 감각 표현이 들어가면 동생이 어떻게 변하는지 다시 상상해 볼까요?</span>
                    </div>
                  )}
                </motion.div>
              )}
            </motion.div>
          ) : (
            /* PHASE 4: Golden Heart-warming Final Explanation summary of pedagogy */
            <motion.div
              key="summary"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-4"
            >
              <div className="bg-gradient-to-br from-[#FF4757]/20 to-[#FFD32D]/10 p-5 rounded-2xl border-3 border-[#FF4757] space-y-4 relative overflow-hidden">
                
                {/* Deco elements */}
                <div className="absolute top-2 right-2 text-xl opacity-20 rotate-12">🍅</div>
                <div className="absolute bottom-2 left-2 text-xl opacity-20 -rotate-12">❤️</div>

                <div className="flex items-center gap-2.5 text-[#FF4757] font-black text-base md:text-xl border-b-2 border-rose-500/20 pb-2">
                  <Sparkles className="w-6 h-6 text-[#FFD32D]" />
                  <span>감각 수사 종결: 동생의 비밀 보고서 📝</span>
                </div>

                <p className="text-sm md:text-lg font-extrabold text-neutral-100 leading-relaxed">
                  여러분은 <strong>방울토마토에 대한 시</strong> 속에서 
                  <span className="text-[#FF4757] font-black underline decoration-white/20"> '빨갛게 익은 얼굴(시각)'</span>, 
                  <span className="text-[#FFD32D] font-black underline decoration-white/20"> '새콤달콤한 즙이 팡(미각)'</span>, 
                  <span className="text-[#2ED573] font-black underline decoration-white/20"> '탱글탱글한 감촉(촉각)'</span>을 샅샅이 찾아내어 연결해 주었어요!
                </p>

                <p className="text-sm md:text-base font-extrabold text-neutral-200 leading-relaxed bg-[#1A1A1A]/90 p-4.5 rounded-xl border border-neutral-800 shadow-[2px_2px_0px_rgba(0,0,0,0.5)]">
                  💡 <strong>감각의 비밀:</strong> 그냥 단순하게 <i>"내 동생은 귀엽고 어리다"</i>라고 설명할 때보다, 방울토마토의 <strong className="text-[#FF4757]">탱글탱글한 감촉</strong>과 <strong className="text-[#FFD32D]">새콤달콤 팡 터지는 즙</strong>에 빗대어 묘사하니까, 동생의 싱그럽고 풋풋한 <strong>귀여움이 백 배 극대화</strong>되어 훨씬 사랑스럽고 생생하게 와닿지요? 😊
                </p>

                <div className="flex items-center gap-2.5 bg-[#FF4757]/10 p-2.5 rounded-lg border border-[#FF4757]/30 text-xs md:text-sm text-rose-300 font-black justify-center">
                  <Heart className="w-4.5 h-4.5 fill-[#FF4757] text-[#FF4757] animate-pulse" />
                  <span>오감 가득 감각 표현은 일상을 한결 더 깜찍하게 만듭니다!</span>
                </div>
              </div>

              <div className="flex justify-end gap-2.5 pt-1">
                <button
                  onClick={handleResetQuiz}
                  className="flex items-center gap-2 px-5 py-3 bg-white hover:bg-neutral-50 text-black font-black text-sm md:text-base border-2 border-black rounded-xl shadow-[4px_4px_0px_#000] hover:scale-102 active:translate-y-0.5 transition-all cursor-pointer"
                >
                  <RotateCcw className="w-4.5 h-4.5" />
                  <span>다시 처음부터 탐색하기</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
